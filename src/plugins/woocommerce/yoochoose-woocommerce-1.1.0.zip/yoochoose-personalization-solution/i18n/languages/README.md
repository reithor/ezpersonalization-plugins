# WARNING! DO NOT PUT CUSTOM TRANSLATIONS HERE!

Yoochoose will delete all custom translations placed in this directory.

## Translating Yoochoose
Put your custom Yoochoose translations in your WordPress language directory, located at: WP_LANG_DIR . "/woocommerce/{$textdomain}-{$locale}.mo";